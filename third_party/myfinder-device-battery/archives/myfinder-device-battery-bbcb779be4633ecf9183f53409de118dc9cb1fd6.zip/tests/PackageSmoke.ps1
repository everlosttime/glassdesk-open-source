param([Parameter(Mandatory=$true)][string]$ZipPath,[Parameter(Mandatory=$true)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
Add-Type -AssemblyName System.IO.Compression.FileSystem
$testRoot=Join-Path ([IO.Path]::GetFullPath($OutputDirectory)) ('package-smoke-'+[Guid]::NewGuid().ToString('N'))
$extracted=Join-Path $testRoot 'unpacked complete package'
$target=Join-Path $testRoot (([string][char]0x4e2d)+[char]0x6587+' installed program')
$data=Join-Path $testRoot 'fake data';$startup=Join-Path $testRoot 'fake Startup';$programs=Join-Path $testRoot 'fake Programs'
New-Item -ItemType Directory -Path $extracted,$startup,$programs -Force | Out-Null
$zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($ZipPath))
try {
    foreach($entry in $zip.Entries) {
        if($entry.FullName.Contains('\')){throw 'The final ZIP contains a backslash entry path.'}
        $candidate=[IO.Path]::GetFullPath((Join-Path $extracted $entry.FullName))
        if(-not $candidate.StartsWith($extracted+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'ZIP entry escapes extraction directory.'}
        if($entry.FullName.EndsWith('/')){continue}
        New-Item -ItemType Directory -Path (Split-Path -Parent $candidate) -Force | Out-Null
        [IO.Compression.ZipFileExtensions]::ExtractToFile($entry,$candidate,$false)
    }
} finally {$zip.Dispose()}
. (Join-Path $extracted 'scripts\Install.Common.ps1')
# Never inspect or change the real user's StartupApproved registry values.
function Get-DeviceBatteryStartupApproval([string]$Name){return $null}
# Keep shell icon refresh inside this fixture instead of notifying the real desktop.
$script:iconRefreshPaths=@()
function Update-DeviceBatteryShellIcons([string]$Executable,[string]$StartupShortcut,[string]$ManualShortcut) {
    $script:iconRefreshPaths=@($Executable,$StartupShortcut,$ManualShortcut)
}
$manifest=Read-DeviceBatteryPackageManifest $extracted
$release=Read-DeviceBatteryRelease $extracted
if("$($release.providerCount)" -notmatch '^\d+$' -or [int]$release.providerCount -le 0){throw 'The package has no valid reader count.'}
$expectedProviderCount=[int]$release.providerCount
# Extract and validate the actual unsigned CI archive using the offline updater validator.
# A release signature is created locally after CI; this never needs the private key.
function Assert-SmokeArchiveValidation([string]$Archive,[string]$Destination,[int]$ExpectedExitCode) {
    $validation=Start-Process -FilePath (Join-Path $extracted 'outputs\AtkMouseBattery.exe') -ArgumentList @('--validate-update-archive',('"'+[IO.Path]::GetFullPath($Archive)+'"'),('"'+$Destination+'"'),$manifest.version) -WindowStyle Hidden -PassThru
    try {
        if(-not $validation.WaitForExit(30000) -or $validation.ExitCode -ne $ExpectedExitCode){throw ('The offline archive validator did not return the expected exit code: '+$ExpectedExitCode)}
    } finally {
        if(-not $validation.HasExited){$validation.Kill();$null=$validation.WaitForExit(5000)}
        $validation.Dispose()
    }
}
$validated=Join-Path $testRoot 'updater validated package'
Assert-SmokeArchiveValidation $ZipPath $validated 0
Assert-SmokeArchiveValidation $ZipPath $validated 1
$null=Read-DeviceBatteryPackageManifest $validated
$invalidArchive=Join-Path $testRoot 'invalid.zip'
[IO.File]::WriteAllBytes($invalidArchive,[byte[]](1,2,3))
Assert-SmokeArchiveValidation $invalidArchive (Join-Path $testRoot 'invalid extraction') 1
# Change only a nested entry separator in an otherwise valid release archive.
# Accepting backslashes would extract the same manifest-valid payload on Windows.
$backslashArchive=Join-Path $testRoot 'backslash.zip'
Copy-Item -LiteralPath $ZipPath -Destination $backslashArchive
Add-Type -AssemblyName System.IO.Compression
$unsafeZip=[IO.Compression.ZipFile]::Open($backslashArchive,[IO.Compression.ZipArchiveMode]::Update)
try {
    $original=$unsafeZip.GetEntry('engine/server.py')
    $renamed=$unsafeZip.CreateEntry('engine\server.py',[IO.Compression.CompressionLevel]::Optimal)
    $source=$original.Open()
    try {$destination=$renamed.Open();try{$source.CopyTo($destination)}finally{$destination.Dispose()}}finally{$source.Dispose()}
    $original.Delete()
} finally {$unsafeZip.Dispose()}
Assert-SmokeArchiveValidation $backslashArchive (Join-Path $testRoot 'backslash extraction') 1
$checksum=Join-Path (Split-Path -Parent $ZipPath) 'SHA256SUMS.txt'
$actualHash=(Get-FileHash -LiteralPath $ZipPath -Algorithm SHA256).Hash.ToLowerInvariant()
$expectedLine=$actualHash+'  '+[IO.Path]::GetFileName($ZipPath)
if(-not (Test-Path -LiteralPath $checksum) -or $expectedLine -cnotin @(Get-Content -LiteralPath $checksum -Encoding UTF8)){throw 'The final ZIP does not match SHA256SUMS.txt.'}
$installed=Install-DeviceBattery -SourceRoot $extracted -InstallDirectory $target -DataDirectory $data -StartupDirectory $startup -ProgramsDirectory $programs
$shortcutShell=New-DeviceBatteryShortcutShell
if($shortcutShell.CreateShortcut($installed.StartupShortcut).IconLocation -cne ($installed.InstalledExecutable+',0')){throw 'The installed startup shortcut does not use the application icon.'}
if($shortcutShell.CreateShortcut($installed.ManualShortcut).IconLocation -cne ($installed.InstalledExecutable+',0')){throw 'The installed manual shortcut does not use the application icon.'}
if($script:iconRefreshPaths.Count -ne 3 -or $script:iconRefreshPaths[0] -cne $installed.InstalledExecutable -or $script:iconRefreshPaths[1] -cne $installed.StartupShortcut -or $script:iconRefreshPaths[2] -cne $installed.ManualShortcut){throw 'Shell icon refresh escaped the isolated installed paths.'}
if(Test-Path -LiteralPath (Join-Path $target 'engine\tests')){throw 'Development protocol fixtures leaked into the release.'}
$preview=Join-Path $testRoot 'preview'
$previewProcess=Start-Process -FilePath $installed.InstalledExecutable -ArgumentList @('--preview',('"'+$preview+'"')) -WindowStyle Hidden -PassThru
try {
    if(-not $previewProcess.WaitForExit(15000) -or $previewProcess.ExitCode -ne 0 -or -not (Test-Path -LiteralPath (Join-Path $preview 'appearance-preview.png'))){throw 'The installed application could not render its offline preview.'}
} finally {
    if(-not $previewProcess.HasExited){$previewProcess.Kill();$null=$previewProcess.WaitForExit(5000)}
    $previewProcess.Dispose()
}

function Start-InstalledSmoke([string]$File,[string]$Arguments) {
    $info=New-Object Diagnostics.ProcessStartInfo
    $info.FileName=$File;$info.Arguments=$Arguments;$info.WorkingDirectory=Split-Path -Parent $File
    $info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.WindowStyle=[Diagnostics.ProcessWindowStyle]::Hidden
    $info.RedirectStandardInput=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
    $process=New-Object Diagnostics.Process;$process.StartInfo=$info
    # Framework Process.Start creates an autoflushing stdin StreamWriter using
    # Console.InputEncoding. An inherited BOM must not prefix JSON Lines.
    $previousInputEncoding=[Console]::InputEncoding
    try {
        [Console]::InputEncoding=New-Object Text.UTF8Encoding($false)
        if(-not $process.Start()){throw 'The installed smoke process did not start.'}
    } finally {[Console]::InputEncoding=$previousInputEncoding}
    return $process
}

function Get-SmokeDescendants([int]$ParentId) {
    $all=@(Get-CimInstance -ClassName Win32_Process -Property ProcessId,ParentProcessId,ExecutablePath)
    $known=New-Object 'System.Collections.Generic.HashSet[int]';$null=$known.Add($ParentId)
    for($round=0;$round -lt 4;$round++) {
        foreach($item in $all){if($known.Contains([int]$item.ParentProcessId)){$null=$known.Add([int]$item.ProcessId)}}
    }
    return @($all | Where-Object {$_.ProcessId -ne $ParentId -and $known.Contains([int]$_.ProcessId)})
}

function Assert-SmokeChildrenExited($Children) {
    foreach($child in @($Children)) {
        $live=Get-Process -Id $child.ProcessId -ErrorAction SilentlyContinue
        if($live) {
            if(-not $live.WaitForExit(5000)) {
                # Only clean up this fixture's exact portable reader path.
                if($live.Path -ieq $child.ExecutablePath -and $live.Path.StartsWith($target+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){$live.Kill();$null=$live.WaitForExit(5000)}
                throw 'An installed smoke child survived its parent.'
            }
            $live.Dispose()
        }
    }
}

function Read-SmokeResult($Process,[int]$ExpectedCount=$expectedProviderCount) {
    # .NET Framework may inherit a BOM-emitting Console.InputEncoding from
    # PowerShell 7. JSON Lines must begin with a JSON token, not a UTF-8 BOM.
    $command=[Text.Encoding]::ASCII.GetBytes('{"command":"poll","requestId":1,"generation":1,"force":true}'+[char]10)
    $Process.StandardInput.BaseStream.Write($command,0,$command.Length)
    $Process.StandardInput.BaseStream.Flush()
    for($frame=0;$frame -lt 64;$frame++) {
        $line=$Process.StandardOutput.ReadLineAsync()
        if(-not $line.Wait(15000) -or [string]::IsNullOrWhiteSpace($line.Result)){throw 'The installed portable worker did not return a bounded result.'}
        $result=$line.Result | ConvertFrom-Json
        if($result.complete) {
            if($result.schema -ne 2 -or $result.packageSmoke -ne $true -or $result.requestId -ne 1 -or $result.generation -ne 1 -or
                $result.providerCount -ne $ExpectedCount -or $result.importedProviderCount -ne $ExpectedCount -or $result.error -or
                @($result.devices).Count -ne 0 -or @($result.errors).Count -ne 0){throw ('The installed portable engine failed its no-hardware self-test: '+($result | ConvertTo-Json -Compress -Depth 6))}
            return $result
        }
    }
    throw 'Too many portable worker progress frames.'
}

function Assert-CountRegressionApp([string]$Root,[int]$ExpectedCount,[int]$ExpectedExit) {
    $process=Start-InstalledSmoke (Join-Path $Root 'outputs\AtkMouseBattery.exe') '--package-smoke'
    try {
        $read=$process.StandardOutput.ReadToEndAsync()
        if(-not $process.WaitForExit(20000) -or -not $read.Wait(2000) -or $process.ExitCode -ne $ExpectedExit){throw 'Reader-count regression returned an unexpected application exit code.'}
        $value=$read.Result.Trim() | ConvertFrom-Json
        if($ExpectedExit -eq 0 -and ($value.providerCount -ne $ExpectedCount -or $value.importedProviderCount -ne $ExpectedCount -or $value.error)){throw 'Application did not accept the added reader.'}
        if($ExpectedExit -ne 0 -and -not $value.error){throw 'Application failed without reporting a smoke error.'}
    } finally {
        if(-not $process.HasExited){$process.Kill();$null=$process.WaitForExit(5000)}
        $process.Dispose()
    }
}

function Test-ProviderCountGrowth {
    # Exercise the same metadata writer used by Package.ps1 against a disposable
    # copy of the real payload, with one additional inert reader and catalog row.
    $fixture=Join-Path $testRoot 'additional reader package'
    Copy-Item -LiteralPath $extracted -Destination $fixture -Recurse
    $utf8=New-Object Text.UTF8Encoding($false)
    $serverPath=Join-Path $fixture 'engine\server.py'
    $server=[IO.File]::ReadAllText($serverPath)
    $server=$server.Replace('PROVIDERS = (',('PROVIDERS = ('+[char]10+'    ("package_count_fixture", "PackageCountFixtureProvider"),'))
    [IO.File]::WriteAllText($serverPath,$server,$utf8)
    $providerPath=Join-Path $fixture 'engine\providers\package_count_fixture.py'
    [IO.File]::WriteAllText($providerPath,"class PackageCountFixtureProvider:`n    pass`n",$utf8)
    $catalogPath=Join-Path $fixture 'engine\compatibility.json'
    $catalog=Get-Content -LiteralPath $catalogPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $entry=$catalog.readers[0] | ConvertTo-Json -Depth 20 | ConvertFrom-Json
    $entry.provider='package_count_fixture';$entry.name='Package count fixture'
    $catalog.readers=@($catalog.readers)+@($entry)
    [IO.File]::WriteAllText($catalogPath,($catalog | ConvertTo-Json -Depth 20),$utf8)
    $null=& (Join-Path $fixture 'engine\runtime\python.exe') -I -B (Join-Path $fixture 'engine\catalog.py') --sync-docs
    if($LASTEXITCODE -ne 0){throw 'Additional reader catalog fixture is invalid.'}
    Write-DeviceBatteryProviderCount $fixture
    $grown=Read-DeviceBatteryRelease $fixture
    if($grown.providerCount -ne ($expectedProviderCount+1)){throw 'Packaging did not derive the additional reader count.'}
    $null=New-DeviceBatteryPackageManifest $fixture
    Assert-CountRegressionApp $fixture $grown.providerCount 0
    $releasePath=Join-Path $fixture 'release.json'
    $saved=[IO.File]::ReadAllText($releasePath)
    # Missing, malformed, absent and mismatched metadata must all fail closed.
    Move-Item -LiteralPath $releasePath -Destination ($releasePath+'.saved')
    try {Assert-CountRegressionApp $fixture 0 1}
    finally {Move-Item -LiteralPath ($releasePath+'.saved') -Destination $releasePath}
    $absent=$saved | ConvertFrom-Json;$absent.PSObject.Properties.Remove('providerCount')
    $grown.providerCount++
    try {
        foreach($invalid in @('{',($absent | ConvertTo-Json -Depth 6),($grown | ConvertTo-Json -Depth 6))) {
            [IO.File]::WriteAllText($releasePath,$invalid,$utf8)
            Assert-CountRegressionApp $fixture 0 1
        }
        $rejected=$false
        try {$null=Read-DeviceBatteryPackageManifest $fixture}catch{$rejected=$true}
        if(-not $rejected){throw 'The manifest accepted changed reader-count metadata.'}
    } finally {[IO.File]::WriteAllText($releasePath,$saved,$utf8)}
    # Keep the declaration/count intact but break the new reader's import.
    [IO.File]::WriteAllText($providerPath,"raise ImportError('fixture import failure')`n",$utf8)
    $rejected=$false
    try {Write-DeviceBatteryProviderCount $fixture}catch{$rejected=$true}
    if(-not $rejected){throw 'Packaging accepted a reader that failed to import.'}
    Assert-CountRegressionApp $fixture 0 1
    Write-Output 'PASS reader-count growth, manifest protection, missing/invalid metadata and failed import regressions'
}

$main=$null;$worker=$null;$children=@()
try {
    # Test the actual installed GUI binary and its real GenericBatteryWorker,
    # not the tiny executable used by the isolated installer unit tests.
    $main=Start-InstalledSmoke $installed.InstalledExecutable '--package-smoke'
    $read=$main.StandardOutput.ReadToEndAsync()
    if(-not $main.WaitForExit(20000) -or -not $read.Wait(2000) -or $main.ExitCode -ne 0){throw 'The installed application/reader smoke harness failed.'}
    $appResult=$read.Result.Trim() | ConvertFrom-Json
    if($appResult.schema -ne 1 -or $appResult.packageSmoke -ne $true -or $appResult.version -cne $manifest.version -or
        $appResult.providerCount -ne $expectedProviderCount -or $appResult.importedProviderCount -ne $expectedProviderCount -or $appResult.error){throw 'The installed application smoke result is invalid.'}
    $main.Dispose();$main=$null
    $worker=Start-InstalledSmoke (Join-Path $target 'engine\runtime\python.exe') ('-I -B -u "'+(Join-Path $target 'engine\server.py')+'" --package-smoke')
    $result=Read-SmokeResult $worker
    $children=Get-SmokeDescendants $worker.Id
    if($children.Count -lt 1){throw 'Real engine isolation children were not exercised.'}
    $worker.StandardInput.BaseStream.Close()
    if(-not $worker.WaitForExit(10000) -or $worker.ExitCode -ne 0){throw 'The installed worker failed to exit on parent pipe EOF.'}
    Assert-SmokeChildrenExited $children
    $worker.Dispose();$worker=$null
    # An abrupt parent exit must also close the private Windows jobs.
    $worker=Start-InstalledSmoke (Join-Path $target 'engine\runtime\python.exe') ('-I -B -u "'+(Join-Path $target 'engine\server.py')+'" --package-smoke')
    $null=Read-SmokeResult $worker
    $children=Get-SmokeDescendants $worker.Id
    if($children.Count -lt 1){throw 'Abrupt-exit child lifecycle was not exercised.'}
    $worker.Kill();$null=$worker.WaitForExit(5000)
    Assert-SmokeChildrenExited $children
    $worker.Dispose();$worker=$null
    $leftovers=@(Get-Process -Name AtkMouseBattery,python,pythonw -ErrorAction SilentlyContinue | Where-Object {$_.Path -and $_.Path.StartsWith($target+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)})
    if($leftovers.Count -gt 0){throw 'Installed package smoke left running child processes.'}
    Test-ProviderCountGrowth
    Uninstall-DeviceBatteryStartup -SourceRoot $extracted -DataDirectory $data -StartupDirectory $startup -ProgramsDirectory $programs -RemoveProgram -RemoveData|Out-Null
    $report=[ordered]@{schema=1;version=$manifest.version;zipSha256=$actualHash;packageFiles=@($manifest.files).Count;
        archiveValidation=$true;backslashArchiveRejected=$true;invalidArchiveRejected=$true;existingExtractionRejected=$true;
        isolatedInstall=$true;actualAppSmoke=$true;portableReaderImports=$true;providerCount=$result.providerCount;
        importedProviderCount=$result.importedProviderCount;providerCountGrowth=$true;invalidProviderCountRejected=$true;failedImportRejected=$true;
        gracefulEofCleanup=$true;abruptParentCleanup=$true;hardwareAccess=$false;realStartupChanged=$false}
    [IO.File]::WriteAllText((Join-Path $testRoot 'package-smoke-result.json'),($report | ConvertTo-Json),(New-Object Text.UTF8Encoding($false)))
    Write-Output ('PASS complete final ZIP smoke: '+$manifest.version+'; actual app + portable worker; no hardware or real startup changes')
} finally {
    foreach($process in @($main,$worker)){if($process){if(-not $process.HasExited){$process.Kill();$null=$process.WaitForExit(5000)};$process.Dispose()}}
    Assert-SmokeChildrenExited $children
}
